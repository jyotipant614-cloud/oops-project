# OOPS Practicals – 5th Semester (Java)

This repository contains all 10 Java programs from the OOPS practical sheet.

## Requirements
- Java JDK 8 or later

## Run a practical
Open a terminal in the practical's folder. Example:

```bash
cd Practical-01-Classes-and-Objects
javac Practical1.java
java Practical1
```

For the other folders, compile and run the matching class: `Practical2`, `Practical3`, ... `Practical10`.

## Practical list
1. Classes and Objects
2. Single, Multilevel, and Hierarchical Inheritance
3. Hybrid and Multiple Inheritance Using Interfaces
4. Method Overloading and Method Overriding
5. Simulating Operator Overloading Using Methods
6. Default, Parameterized, and Copy Constructors
7. Object Lifecycle and Garbage Collection
8. Constructor Overloading
9. `this` Keyword, Constructor Chaining, and Static Members
10. Encapsulation Using Getters, Setters, and Validation

## Upload this project to GitHub
1. Create a new repository on GitHub, for example `OOPS-Practicals-5th-Sem`.
2. Extract this ZIP file.
3. Upload the extracted folders and `README.md` to your repository, or run these commands from the extracted project folder:

```bash
git init
git add .
git commit -m "Add OOPS Java practicals"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/OOPS-Practicals-5th-Sem.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and use your own repository URL.
